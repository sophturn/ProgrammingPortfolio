import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Etch_A_Sketch extends PApplet {

int x, y; //global variables - always in memory while the app runs

public void setup() {
  
  frameRate(10);
  //start coordinates
  x=0;
  y=0;
}

public void draw() {
  fill(0);
  drawName();
  noLoop();
}

//draw lines to the right
public void moveRight(int rep) {
  for (int i=0; i<rep; i++) {
    point(x+i, y);
  }
  x=x+(rep);
}

//draw lines to the left
public void moveLeft(int rep) {
  for (int i=0; i<rep; i++) {
    point(x-i, y);
  }
  x=x-rep;
}

//draw lines up
public void moveUp(int rep) {
  for (int i=0; i<rep; i++) {
    point(x, y-i);
  }
  y=y-rep;
}

//draw lines down
public void moveDown(int rep) {
  for (int i=0; i<rep; i++) {
    point(x, y+i);
  }
  y=y+rep;
}

//draw diagonal lines rigth/up
public void diagonalRightUp(int rep) {
  for (int i=0; i<rep; i++) {
    point(x+i, y-i);
  }
  x=x+rep;
  y=y-rep;
}

//draw diagonal lines right/down
public void diagonalRightDown(int rep) {
  for (int i=0; i<rep; i++) {
    point(x+i, y+i);
  }
  x=x+rep;
  y=y+rep;
}

//draw diagonal lines left/up
public void diagonalLeftUp(int rep) {
  for (int i=0; i<rep; i++) {
    point(x-i, y-i);
  }
  x=x-rep;
  y=y-rep;
}

//draw diagonal lines left/down
public void diagonalLeftDown(int rep) {
  for (int i=0; i<rep; i++) {
    point(x-i, y+i);
  }
  x=x-rep;
  y=y+rep;
}

public void drawName() {
  //S
  moveRight(50);
  moveDown(20);
  moveLeft(35);
  diagonalLeftDown(5);
  moveDown(35);
  diagonalRightDown(5);
  moveRight(30);
  diagonalRightDown(5);
  moveDown(35);
  diagonalLeftDown(5);
  moveLeft(35);
  //O
  moveRight(65);
  moveRight(35);
  diagonalRightUp(5);
  moveUp(80);
  diagonalLeftUp(5);
  moveLeft(35);
  diagonalLeftDown(5);
  moveDown(80);
  diagonalRightDown(5);
  //P
  moveRight(65);
  moveUp(85);
  diagonalRightUp(5);
  moveRight(35);
  diagonalRightDown(5);
  moveDown(35);
  diagonalLeftDown(5);
  moveLeft(35);
  diagonalLeftUp(5);
  //H
  diagonalRightDown(5);
  moveRight(65);
  moveUp(45);
  moveDown(90);
  moveUp(45);
  moveRight(35);
  moveUp(45);
  moveDown(90);
  //I
  moveRight(25);
  moveRight(60);
  moveLeft(30);
  moveUp(90);
  moveLeft(30);
  moveRight(60);
  //A
  moveRight(40);
  moveLeft(30);
  moveDown(90);
  moveUp(90);
  moveRight(45);
  moveDown(90);
  moveUp(45);
  moveLeft(45);
}
  public void settings() {  size(400, 400); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Etch_A_Sketch" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}

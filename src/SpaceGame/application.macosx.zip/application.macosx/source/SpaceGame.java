import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class SpaceGame extends PApplet {

// Space Game | December 2020
// by Sophia Turner

SpaceShip s1;
ArrayList<Star> stars;
ArrayList<Asteroid> asteroids;
ArrayList<Projectile> lasers;
ArrayList<EnemyShip> enemies;
ArrayList<EnemyProjectile> enemyLasers;
ArrayList<PowerUp> pUps;
int score, eX;
boolean play;
Timer asteroidTimer, puTimer, enemyTimer, laserTimer;

public void setup() {
  
  s1 = new SpaceShip(0xff195ECB);
  s1.x = width/2;
  stars = new ArrayList();
  asteroids = new ArrayList();
  lasers = new ArrayList();
  enemies = new ArrayList();
  enemyLasers = new ArrayList();
  pUps = new ArrayList();
  asteroidTimer = new Timer(PApplet.parseInt(random(2000, 4000)));
  enemyTimer = new Timer(PApplet.parseInt(random(2000, 4000)));
  puTimer = new Timer(PApplet.parseInt(random(10000, 50000)));
  laserTimer = new Timer(1000);
  score = 0;
  play = false;
  asteroidTimer.start();
  puTimer.start();
  enemyTimer.start();
}

public void draw() {
  noCursor();
  println("keyCode: " + keyCode + ", " + play);

  //game play
  if (!play) {
    startScreen();
  } else {
    background(0);
    stars.add(new Star(250));
    for (int i = 0; i < stars.size(); i++) {
      Star star = stars.get(i);
      star.display();
      star.travel();
      if (star.reachedBottom()) {
        stars.remove(star);
      }
    }

    for (int i = 0; i < lasers.size(); i++) {
      Projectile laser = lasers.get(i);
      laser.display();
      laser.fire();
      for (int j = 0; j < asteroids.size(); j++) {
        Asteroid asteroid = asteroids.get(j);
        if (asteroid.laserIntersect(laser)) {
          asteroid.hp -=1;
          lasers.remove(laser);
          score+=1;
          if (asteroid.hp<1) {
            asteroids.remove(asteroid);
            score += 2;
          }
        }
      }
      if (laser.reachedTop()) {
        lasers.remove(laser);
      }
    }

    for (int i = 0; i < enemyLasers.size(); i++) {
      EnemyProjectile enemyLaser = enemyLasers.get(i);
      enemyLaser.display();
      enemyLaser.fire();
      if (enemyLaser.reachedBottom()) {
        enemyLasers.remove(enemyLaser);
      }
    }

    for (int i = 0; i < enemies.size(); i++) {
      EnemyShip enemy = enemies.get(i);
      enemy.display();
      enemy.move();
      for (int j = 0; j < lasers.size(); j++) {
        Projectile laser = lasers.get(j);
        if (enemy.laserIntersect(laser)) {
          enemy.hp -=1;
          lasers.remove(laser);
          score+=1;
          if (enemy.hp<1) {
            enemies.remove(enemy);
            score += 2;
          }
        }
      }
    }

    s1.display(s1.x, height-83);
    if (s1.hp < 1) {
      s1.lives -=1;
      s1.hp = 25;
    }
    for (int j = 0; j < enemyLasers.size(); j++) {
      EnemyProjectile enemyLaser = enemyLasers.get(j);
      if (s1.shipIntersect(enemyLaser)) {
        s1.hp -=1;
        enemyLasers.remove(enemyLaser);
        score+=1;
      }
    }

    if (asteroidTimer.isFinished()) {
      asteroids.add(new Asteroid(PApplet.parseInt(random(width)), 0));
      asteroidTimer.start();
    }

    if (puTimer.isFinished()) {
      pUps.add(new PowerUp());
      puTimer.start();
    }

    if (enemyTimer.isFinished()) {
      enemies.add(new EnemyShip(PApplet.parseInt(random(width)), 0, 0xff017109));
      enemyTimer.start();
    }

    if (laserTimer.isFinished()) {
      enemyLasers.add(new EnemyProjectile(eX, 0, 0xff009B18));
      laserTimer.start();
    }

    for (int i = 0; i < asteroids.size(); i++) {
      Asteroid asteroid = asteroids.get(i);
      asteroid.display();
      asteroid.move();
      if (s1.asteroidIntersect(asteroid)) {
        s1.hp-=asteroid.hp;
        asteroids.remove(asteroid);
        score += asteroid.hp;
      }
      if (asteroid.reachedBottom()) {
        asteroids.remove(asteroid);
      }
    }

    infoPanel();

    //Game Over logic
    if (s1.lives<0) {
      play = false;
      gameOver();
    }
  }
}

public void keyPressed() {
  //use spacebar for fire
  if (keyCode == 32) {
    lasers.add(new Projectile(s1.x-1, s1.y, 0xffF52020));
    play = true;
  }
  //move with arrow keys
  if (keyCode == 39) {
    s1.x+=s1.speed;
  } else if (keyCode == 37) {
    s1.x-=s1.speed;
  }
}

public void startScreen() {
  background(0);
  textAlign(CENTER);
  text("Welcome to Space Game!", width/2, height/2);
  text("Press Space Bar to Start", width/2, height/2+20);
}

public void gameOver() {
  background(0);
  textAlign(CENTER);
  text("Game Over", width/2, height/2);
  text("Score: " + score, width/2, height/2+20);
  noLoop();
}

public void infoPanel() {
  fill(120, 120);

  textAlign(CENTER);
  rect(0, height-40, width, 40);
  fill(0, 120);
  textSize(15);
  fill(200);
  text("Lives: " + s1.lives, width/6, height-18);
  text("Health: " + s1.hp, width/2, height-18);
  text("Score: " + score, 5*width/6, height-18);
}
class Asteroid {
  //member variables
  int x, y, speed, hp, rad;
  

  //constructor
  Asteroid(int x, int y) {
    this.x=x;
    this.y=y;
    speed = PApplet.parseInt(random(1, 4));
    hp = 3;
    rad = 18;
  }

  public boolean reachedBottom() {
    if (y>height) {
      return true;
    } else {
      return false;
    }
  }

  public void move() {
    y+=speed;
  }

  //member methods
  public void display() {
    fill(0xff625545);
    quad(x-16, y-1, x+2, y-14, x+16, y+1, x-2, y+14);
    quad(x-9, y-10, x+10, y-10, x+11, y+11, x-10, y+9);
    fill(0);
    ellipse(x, y, 5, 5);
  }
  
    //col dect rock vs laser
  public boolean laserIntersect(Projectile laser) {
    float distance = dist(x, y, laser.x, laser.y);
    if(distance < rad + laser.rad) {
      return true; 
    } else {
      return false;
    }
  }
}
class EnemyProjectile {

  //member variables

  int x, y, speed, rad;

  int c;


  //constructor
  EnemyProjectile(int x, int y, int c) {
    this.x=x;
    this.y = y;
    speed = -5;
    rad = 1;
    this.c = c;
  }

  public void fire() {
    y+=speed;
  }


  public boolean reachedBottom() {
    if (y>height) {
      return true;
    } else {
      return false;
    }
  }


  //member methods
  public void display() {
    fill(c);
    noStroke();
    rect(x, y, 2, 8);
  }
}
class EnemyShip {
  //member variables
  int x, y, hp, xspeed, rad;
  int c;

  //constructor 
  EnemyShip(int x, int y, int c) {
    this.x=x;
    this.y=y;
    hp = 5;
    xspeed = PApplet.parseInt(random(1, 2));
    rad = 20;
    this.c = c;
    eX = x;
  }

  public boolean reachedBottom() {
    if (y>height) {
      return true;
    } else {
      return false;
    }
  }

  public void move() {
    x+=xspeed;
    if (x>width-20 || x<20) {
      xspeed*=-1;
    }
  }


  //member methods
  public void display() {
    fill(c);
    rect(x, y, 10, 20);
    quad(x, y+20, x, y+10, x-15, y, x-5, y+20);
    quad(x+10, y+20, x+10, y+10, x+25, y, x+15, y+20);
    triangle(x-5, y+20, x+15, y+20, x+5, y+30);
    rect(x-3, y+22, 1, 5);
    rect(x+12, y+22, 1, 5);
    triangle(x-3, y-5, x+13, y-5, x+5, y+7);
    fill(0);
    quad(x, y+20, x+2, y+23, x+8, y+23, x+10, y+20);
  }

  //col dect laser vs ship
  public boolean laserIntersect(Projectile laser) {
    float distance = dist(x, y, laser.x, laser.y);
    if (distance < rad + laser.rad) {
      return true;
    } else {
      return false;
    }
  }
}
class PowerUp {
  //member variables
  int x, y, speed, rad, pu;
  String[] puInfo = {"HP", "Lasers", ""};

  //constructor
  PowerUp() {
    x = 0;
    y = 0;
    speed = PApplet.parseInt(random(1,4));
    
  }

  public boolean reachedBottom() {
    if (y>height) {
      return true;
    } else {
      return false;
    }
  }

  //member methods
  public void display() {
    fill(0, 250, 0);
    ellipse(x, y, 20, 20);
  }
}
class Projectile {
  //member variables
  int x, y, speed, rad;
  int c;

  //constructor
  Projectile(int x, int y, int c) {
    this.x = x;
    this.y = y;
    speed = 5;
    rad = 1;
    this.c = c;
  }

  public void fire() {
    y-=speed;
  }

  public boolean reachedTop() {
    if (y<0) {
      return true;
    } else {
      return false;
    }
  }

  //member methods
  public void display() {
    fill(c);
    noStroke();
    rect(x, y, 2, 8);
  }
}
class SpaceShip {
  //member variables
  int x, y, hp, lives, speed, rad;
  int c;

  //constructor 
  SpaceShip(int c) {
    hp = 25;
    lives = 3;
    speed = 20;
    rad = 25;
    this.c = c;
  }

  //member methods
  public void display(int x, int y) {
    this.x=x;
    this.y=y;
    //point
    fill(100, 100, 100);
    triangle(x-10, y-25, x, y-49, x+10, y-25);
    rect(x-10, y-25, 20, 10);
    noStroke();
    rect(x-10, y-25, 20, 1);
    //surround point
    fill(175, 0, 0);
    noStroke();
    quad(x-13, y-10, x-20, y-5, x-20, y-25, x-13, y-35);
    triangle(x-20, y-25, x-7, y-52, x-13, y-30);
    quad(x+13, y-10, x+20, y-5, x+20, y-25, x+13, y-35);
    triangle(x+20, y-25, x+7, y-52, x+13, y-30);
    //body
    fill(c);
    noStroke();
    rect(x-13, y-15, 26, 50, 3);
    //wings
    fill(175, 0, 0);
    noStroke();
    quad(x-13, y-5, x-27, y+5, x-29, y+15, x-13, y+5);
    quad(x+13, y-5, x+27, y+5, x+29, y+15, x+13, y+5);
    quad(x-13, y+10, x-35, y+25, x-37, y+30, x-13, y+30);
    quad(x+13, y+10, x+35, y+25, x+37, y+30, x+13, y+30);
    //engines
    fill(175, 100, 0);
    rect(x-8, y+35, 5, 7);
    rect(x+3, y+35, 5, 7);
  }


  //col dect rock vs ship
  public boolean asteroidIntersect(Asteroid asteroid) {
    float distance = dist(x, y, asteroid.x, asteroid.y);
    if (distance < rad + asteroid.rad) {
      return true;
    } else {
      return false;
    }
  }

  //col dect enemy laser vs ship
  public boolean shipIntersect(EnemyProjectile laser) {
    float distance = dist(x, y, laser.x, laser.y);
    if (distance < rad + laser.rad) {
      return true;
    } else {
      return false;
    }
  }
}
class Star {
  //member variables
  float x, y, speed;
  int c;

  //constructor
  Star(int c) {
    x = random(width);
    y = 0;
    speed = 2;
    this.c = c;
  }

  public void travel() {
    y+= speed;
  }

  public boolean reachedBottom() {
    if (y>height) {
      return true;
    } else {
      return false;
    }
  }

  //member methods
  public void display() {
    noStroke();
    fill(c);
    ellipse(x, y, 2, 2);
  }
}
// Example 10-5: Object-oriented timer
// by Daniel Shiffman

class Timer {

  int savedTime; // When Timer started
  int totalTime; // How long Timer should last

  Timer(int tempTotalTime) {
    totalTime = tempTotalTime;
  }

  // Starting the timer
  public void start() {
    // When the timer starts it stores the current time in milliseconds.
    savedTime = millis();
  }

  // The function isFinished() returns true if 5,000 ms have passed. 
  // The work of the timer is farmed out to this method.
  public boolean isFinished() { 
    // Check how much time has passed
    int passedTime = millis()- savedTime;
    if (passedTime > totalTime) {
      return true;
    } else {
      return false;
    }
  }
}
  public void settings() {  size(400, 400); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "SpaceGame" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
